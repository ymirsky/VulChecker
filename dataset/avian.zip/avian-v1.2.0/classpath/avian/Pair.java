package avian;

abstract class Pair {
  // VM-visible fields in types.def
}
